<?php
session_start();

error_reporting(0);
  $newtok = $_SESSION['logtok'];

if(isset($_GET['logout'])&&isset($_GET['token'])){
  if($_GET['token']==$_SESSION['logtok']){
    
    if(isset($_SESSION['username'])){
        unset($_SESSION['username']);
        session_destroy();
        header('Location: ../login.php');
    } else{
        header('Location: ../login.php');
    }
  } else{
    echo "<script>alert('Invalid Method')</script>";
  }
}
