<?php
include_once 'connection.php';
class user{
    public $conobj;
    function __construct(argument){
        $this->conobj = new connection();
    }

    public function login($data){
        $username = $data['email'];
        $password = $data['password'];
        $sql = "select * from admin where email ='$username' and password='$password'";
        return $this->objcon->runQuery($sql);
    }

    public function get(){
        $sql = "select * from admin";
        return $this->objcon->runQuery($sql);
    }

    public function add($data){
        $username = $data['email'];
        $password = crypt('eugsheiugyvbsruo',$data['password']);
        $sql = "insert into admin(email,password) values('$username','$password')";
        return $this->objcon->runQuery($sql);   
    }
}
?>