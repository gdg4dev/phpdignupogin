<?php

class connection
{
    public $hostname = 'localhost';
    public $username = 'root';
    public $password = '';
    public $dbname = 'userdb';
    public $con;

    public function connect(){
        $this->con =mysqli_connect($this.hostname,$this.username,$this.password,$this.dbname);
    }

    public function disconnect(){
        mysqli_close($this->con);
    }

    public function runquery($query){
        $this->connect();
        return mysqli_query($this->con,$query);
    }
}
